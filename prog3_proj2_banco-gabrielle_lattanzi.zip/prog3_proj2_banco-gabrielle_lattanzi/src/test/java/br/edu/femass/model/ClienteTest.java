package br.edu.femass.model;

import org.junit.jupiter.api.Test;

public class ClienteTest {

    @Test
    void criarClienteCpfValido() {

    }

    @Test
    void criarClienteCpfInvalido() {

    }

    @Test
    void criarContaGerandoNumero() {

    }


}
