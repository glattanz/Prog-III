package br.edu.femass.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContaTest {

    @Test
    void creditarValorConta() {

    }

    @Test
    void debitarValorContaComSaldo() {

    }

    @Test
    void debitarValorContaSemSaldo() {

    }

    @Test
    void validarHistoricoLancamentos() {

    }

}